package com.end.finalproject.model;

import java.util.List;

public class BankResponse {
    public String code;
    public String desc;
    public List<Bank> data;
}
