package com.end.finalproject.model;

public class TransferResponse {
    public String status;
    public String transactionId;
    public String message;
}
