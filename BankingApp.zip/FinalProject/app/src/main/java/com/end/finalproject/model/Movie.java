package com.end.finalproject.model;

public class Movie {
}
