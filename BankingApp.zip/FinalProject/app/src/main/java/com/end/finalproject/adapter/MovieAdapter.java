package com.end.finalproject.adapter;

public class MovieAdapter {
}
